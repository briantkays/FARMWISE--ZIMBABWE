FarmWise Zimbabwe MVP 0.1

CONTENTS
- index.html: working mobile-friendly app
- manifest.webmanifest: installable web app metadata
- sw.js: basic offline cache for supported browsers
- README.txt: these instructions

TRY IT
1. Open index.html in a modern browser to test the planner and calculators.
2. For install prompt and offline caching, host the folder on HTTPS (for example GitHub Pages). Service workers and PWA install generally do not work from a local file:// URL.
3. On Android Chrome, visit the HTTPS website and choose browser menu > Install app or Add to Home screen.

CURRENT FEATURES
- Enterprise selection and starter planning prompts
- USD budget and land inputs
- Profit / break-even calculator with loss percentage
- Introductory guides and indicative timelines
- Save/load farm inputs in local browser storage

IMPORTANT LIMITATIONS
- No user accounts or cloud sync
- No verified live Zimbabwe prices, weather, soil map, supplier data or market feed
- Production guides are introductory; exact dimensions, stocking density, feed schedules, vaccination, permits and planting windows must be verified for the specific site with qualified local advisers.
- Financial results are estimates, not a guarantee of profit.
